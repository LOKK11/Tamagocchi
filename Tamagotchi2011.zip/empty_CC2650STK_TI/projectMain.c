/*
 * Copyright (c) 2015-2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== empty.c ========
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>

/* Board Header files */
#include "Board.h"

#include <string.h>
#include <ti/drivers/UART.h>
#include <stdio.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/i2c/I2CCC26XX.h>
#include <ti/drivers/Power.h>
#include <ti/drivers/power/PowerCC26XX.h>
#include "sensors/mpu9250.h"
#include "sensors/opt3001.h"
#include "sensors/tmp007.h"
#include "CC2650STK.h"
#include "wireless/comm_lib.h"
#include "buzzer.h"


#define SERIALSTACKSIZE 1024
#define SENSORSTACKSIZE 2048

Char serialTaskStack[SERIALSTACKSIZE];
Char mpuTaskStack[SENSORSTACKSIZE];
Char sensorTaskStack[SENSORSTACKSIZE];

enum state {WAITING=0, EAT, ACTIVATE, PET, EXERCISE, PANIC};
enum state programState = WAITING;
enum communication {RADIO=0,GATEWAY};
enum communication commState = GATEWAY;
enum moves {PRIMARY=0,SECONDARY};
enum moves moveState = PRIMARY;

float ax, ay, az, gx, gy, gz;
float temperature = -100.0;
double light = -1000.0;

char eatmsg[20]="id:3031,EAT:2";
char exercisemsg[20]="id:3031,EXERCISE:2";
char petmsg[20]="id:3031,PET:2";
char activatemsg[25]="id:3031,ACTIVATE:1;1;1";
char uartBuffer[10];
char panicMsg[9] = "3031,BEEP";

/* Pin driver handle */
static PIN_Handle hMpuPin;

static PIN_Handle ledHandle;
static PIN_State ledState;

static PIN_Handle ledHandle1;
static PIN_State ledState1;

static PIN_Handle hBuzzer;
static PIN_State sBuzzer;

static PIN_Handle rightButtonHandle;             //right button
static PIN_State rightButtonState;

void sendMsg(UART_Handle handle, char *msg, int length);
//static PIN_Handle ledHandle;
//static PIN_State ledState;

PIN_Config rightButtonConfig[] = {
   Board_BUTTON0  | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
   PIN_TERMINATE };

PIN_Config rightButtonWakeConfig[] = {
   Board_BUTTON0  | PIN_INPUT_EN | PIN_PULLUP | PINCC26XX_WAKEUP_NEGEDGE,
   PIN_TERMINATE
};

PIN_Config ledConfig[] = {
   Board_LED0 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
   PIN_TERMINATE
};

PIN_Config ledConfig1[] = {
   Board_LED1 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
   PIN_TERMINATE
};

PIN_Config cBuzzer[] = {
  Board_BUZZER | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
  PIN_TERMINATE
};

static const I2CCC26XX_I2CPinCfg i2cMPUCfg = {
    .pinSDA = Board_I2C0_SDA1,
    .pinSCL = Board_I2C0_SCL1
};

//Right button is the power button
void rightButtonFxn(PIN_Handle handle, PIN_Id pinId) {



}

Void sensorTask(UArg arg0, UArg arg1) {


        uint8_t tickCounter = 0;

        I2C_Handle i2cMPU; // Own i2c-interface for MPU9250 sensor
        I2C_Params i2cMPUParams;
        I2C_Handle i2c;
        I2C_Params i2cParams;

        I2C_Params_init(&i2cMPUParams);
        i2cMPUParams.bitRate = I2C_400kHz;

        // Note the different configuration below
        i2cMPUParams.custom = (uintptr_t)&i2cMPUCfg;

        // MPU power on
        PIN_setOutputValue(hMpuPin,Board_MPU_POWER, Board_MPU_POWER_ON);

        // Wait 100ms for the MPU sensor to power up
        Task_sleep(100000 / Clock_tickPeriod);
        System_printf("MPU9250: Power ON\n");
        System_flush();

        // MPU open i2c
        i2cMPU = I2C_open(Board_I2C, &i2cMPUParams);
        if (i2cMPU == NULL) {
            System_abort("Error Initializing I2CMPU\n");
        }

        // MPU setup and calibration
        System_printf("MPU9250: Setup and calibration...\n");
        System_flush();

        mpu9250_setup(&i2cMPU);
        Task_sleep(500000 / Clock_tickPeriod);

        System_printf("MPU9250: Setup and calibration OK\n");
        System_flush();

        I2C_close(i2cMPU);

        I2C_Params_init(&i2cParams);
        i2cParams.bitRate = I2C_400kHz;

        i2c = I2C_open(Board_I2C_TMP, &i2cParams);
        if (i2c == NULL) {
          System_abort("Error Initializing I2C\n");
        }
        tmp007_setup(&i2c);
        Task_sleep(100000/ Clock_tickPeriod);
        I2C_close(i2c);

        i2c = I2C_open(Board_I2C_TMP, &i2cParams);
        if (i2c == NULL) {
           System_abort("Error Initializing I2C\n");
        }
        opt3001_setup(&i2c);
        Task_sleep(100000/ Clock_tickPeriod);
        I2C_close(i2c);

        // Loop forever
        while (1) {
            i2cMPU = I2C_open(Board_I2C, &i2cMPUParams);
            if (i2cMPU == NULL) {
                System_abort("Error Initializing I2CMPU\n");
            }
            float tempGz = gz;
            float tempAz = az;
            float tempAy = ay;
            mpu9250_get_data(&i2cMPU, &ax, &ay, &az, &gx, &gy, &gz);
            I2C_close(i2cMPU);
            if (tempGz > 150) {
                if (gz < -150) {
                    programState = EAT;
                }
            }

            if (tempAz < -1.5) {
                if (az > -0.5) {
                    programState = ACTIVATE;
                }
            }

            if (tempAy > 0.3) {
                if (ay < -0.3) {
                    programState = EXERCISE;
                }
            }
            if (tickCounter == 0) {
                i2c = I2C_open(Board_I2C_TMP, &i2cParams);
                temperature = tmp007_get_data(&i2c);
                light = opt3001_get_data(&i2c);
                I2C_close(i2c);
                if (light < 1 && temperature > 36) {
                    programState = PET;
                }
            }
            ++tickCounter;
            if (tickCounter >= 26) {
                tickCounter = 0;
            }
            Task_sleep(200000 / Clock_tickPeriod);
        }

        // Program never gets here..
        // MPU close i2c
        // I2C_close(i2cMPU);
        // MPU power off
        // PIN_setOutputValue(hMpuPin,Board_MPU_POWER, Board_MPU_POWER_OFF);
}



Void uartFxn(UART_Handle uart, void *rxBuf, size_t size) {
    if (strncmp(rxBuf, panicMsg, 9) == 0) {
        programState = PANIC;
        return;
    }
    UART_read(uart, rxBuf, 80);
}

Void serialTask(UArg arg0, UArg arg1) {

    // UART-kirjaston asetukset
    UART_Handle uart;
    UART_Params uartParams;

    // Alustetaan sarjaliikenne
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_TEXT;
    uartParams.readDataMode = UART_DATA_TEXT;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.readMode = UART_MODE_CALLBACK;
    uartParams.readCallback = &uartFxn;
    uartParams.baudRate = 9600; // nopeus 9600baud
    uartParams.dataLength = UART_LEN_8; // 8
    uartParams.parityType = UART_PAR_NONE; // n
    uartParams.stopBits = UART_STOP_ONE; // 1

    // Avataan yhteys laitteen sarjaporttiin vakiossa Board_UART0
    uart = UART_open(Board_UART0, &uartParams);
    if (uart == NULL) {
       System_abort("Error opening the UART");
    }
    UART_read(uart, uartBuffer, 80);

    // Ikuinen elämä
    while (1) {
        PIN_setOutputValue( ledHandle, Board_LED0, 0 );
        PIN_setOutputValue( ledHandle1, Board_LED1, 0 );

       switch (programState) {
          case EAT:
              sendMsg(uart, eatmsg, strlen(eatmsg));
              programState = WAITING;
              PIN_setOutputValue( ledHandle, Board_LED0, 1 );
              break;
          case EXERCISE:
              sendMsg(uart, exercisemsg,strlen(exercisemsg));
              programState = WAITING;
              PIN_setOutputValue( ledHandle1, Board_LED1, 1 );
              break;
          case PET:
              sendMsg(uart, petmsg,strlen(petmsg));
              programState = WAITING;
              buzzerOpen(hBuzzer);
              buzzerSetFrequency(500);
              Task_sleep(100000 / Clock_tickPeriod);
              buzzerClose();
              break;
          case ACTIVATE:
              sendMsg(uart, activatemsg,strlen(activatemsg));
              programState = WAITING;
              PIN_setOutputValue( ledHandle1, Board_LED1, 1 );
              PIN_setOutputValue( ledHandle, Board_LED0, 1 );
              buzzerOpen(hBuzzer);
              buzzerSetFrequency(1000);
              Task_sleep(100000 / Clock_tickPeriod);
              buzzerClose();
              break;
          case PANIC:
              programState = WAITING;
              buzzerOpen(hBuzzer);
              buzzerSetFrequency(4000);
              Task_sleep(100000 / Clock_tickPeriod);
              buzzerClose();
              break;
          default:
              //programState was something else.
              break;
       // Let's sleep for one second
       }
       Task_sleep(1000000 / Clock_tickPeriod);
    }
}

void sendMsg(UART_Handle handle, char *msg, int length) {
        UART_write(handle, msg, length + 1);
}
/*

 *  ======== main ========
 */
int main(void)
{
    Task_Params serialTaskParams;
    Task_Handle serialTaskHandle;
    Task_Params sensorTaskParams;
    Task_Handle sensorTaskHandle;

    /* Call board init functions */
    Board_initGeneral();
    Board_initUART();
    Board_initI2C();

    Task_Params_init(&serialTaskParams);
    // Define task stack memory
    serialTaskParams.stackSize = SERIALSTACKSIZE;
    serialTaskParams.stack = &serialTaskStack;
    // Set task priority
    serialTaskParams.priority = 2;

    rightButtonHandle = PIN_open(&rightButtonState, rightButtonConfig);
    if(!rightButtonHandle) {
                System_abort("Error initializing button pins\n");
    }

    ledHandle = PIN_open(&ledState, ledConfig);
      if(!ledHandle) {
         System_abort("Error initializing LED pins\n");
    }

    hBuzzer = PIN_open(&sBuzzer, cBuzzer);
    if (hBuzzer == NULL) {
       System_abort("Pin open failed!");
    }

      ledHandle1 = PIN_open(&ledState1, ledConfig1);
         if(!ledHandle1) {
            System_abort("Error initializing LED pins\n");
       }

    if (PIN_registerIntCb(rightButtonHandle, &rightButtonFxn) != 0) {
             System_abort("Error registering right button callback function");
    }

    serialTaskHandle = Task_create(serialTask, &serialTaskParams, NULL);
    if (serialTaskHandle == NULL) {
       System_abort("Task create failed");
    }

    Task_Params_init(&sensorTaskParams);
    // Define task stack memory
    sensorTaskParams.stackSize = SENSORSTACKSIZE;
    sensorTaskParams.stack = &sensorTaskStack;
    // Set task priority
    sensorTaskParams.priority = 2;

    sensorTaskHandle = Task_create(sensorTask, &sensorTaskParams, NULL);
    if (sensorTaskHandle == NULL) {
       System_abort("Task create failed");
    }

    System_printf("Hello world\n");
    System_flush();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
